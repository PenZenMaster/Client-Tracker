from chatgpt_background import run

client_config = {
    "name": "Tri-State Heating & Cooling, LLC",
    "address": "7686 Rome Rd, Adrian, MI 49221",
    "url": "https://www.tri-stateheating.com/",
    "mobile_url": "https://www.tristate-hvac.com/",
    "gbp_url": "https://g.co/kgs/j3Bb4gy",
    "output_root": r"C:\Users\georg\OneDrive\RankRocket\Clients\Patrick Rombyer"
}

run(client_config)